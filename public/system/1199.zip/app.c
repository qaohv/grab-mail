#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#include <security/pam_appl.h>
#include <security/pam_misc.h>

 int main(int argc, char* argv[]) {
//    char* userLogin = argv[1] ;
//    char* userPassword = argv[2] ; 

//    printf("Your login is: %s\n", userLogin) ; 
//    printf("Your password is: %s\n", userPassword) ;

    //auth with pam
   int returnCode ; 
   pam_handle_t* pamh ; 
   struct pam_conv conv ; 
   conv.conv = misc_conv ; 
   conv.appdata_ptr = NULL ; 

   returnCode = pam_start("login", NULL, &conv, &pamh) ; 
   returnCode = pam_authenticate(pamh, 0) ; 
   printf("returnCode is: %d\n", returnCode) ;   
   printf("result operation is: %s\n", pam_strerror(pamh, returnCode)) ;  
   pam_end(pamh, returnCode) ;
	
   printf("Auth complete!\n") ; 
 
    //generate random bit
    srand(time(NULL)) ; 
    int random = rand() % 2 ;
     if(random == 0) {
	printf("Change password!\n") ; 

     } else {
	printf("Not changes\n") ;
       }
    


    return 0 ;
 }
